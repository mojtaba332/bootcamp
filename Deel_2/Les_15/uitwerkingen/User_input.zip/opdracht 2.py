#opdracht 2

# Schrijf een functie met twee parameters (integers).
# De functie retourneert de vermenigvuldiging van de twee parameters.


def sommeer(getal_1, getal_2):
    vermeningvukdig = getal_1 * getal_2
    return vermeningvukdig

getal_1 = 33
getal_2 = 2

resultaat_van_vermenig = sommeer(getal_1, getal_2) 
print(f"de vermenigvuldiging van{getal_1} en {getal_2} is {resultaat_van_vermenig} ")
