#opdracht 1


def sommeer(getal_1, getal_2): # parameters kun je gebriuk als var in je functie
    som = getal_1 + getal_2
    return som


getal_1 = 4
getal_2 = 8

resultaat = sommeer(getal_1, getal_2)
print(f"het antwoord op de som van {getal_1} en {getal_2} is: {resultaat}")
