keuze = input("maak uw keuze (a,b,c):")
omschrijving = ''


if keuze == 'a':
    omschrijving = 'Oke'
elif keuze == 'b':
    omschrijving = 'Done'
elif keuze == 'c':
    omschrijving = 'Finish'
