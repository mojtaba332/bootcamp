totlal = 625
count = 0


while totlal >= 12:
    totlal -= 12
    count += 1

print("het aantal keer dat 12 in 625 past is", count)