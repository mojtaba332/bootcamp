#Opdracht 3: 
#Bereken met een while loop hoeveel keer 25 in 625 past.
#(Let op: max. 8 regels code!)


totlal = 625
count = 0


while totlal >= 25:
    totlal -= 25
    count += 1

print("het aantal keer dat 25 in 625 past is", count)


