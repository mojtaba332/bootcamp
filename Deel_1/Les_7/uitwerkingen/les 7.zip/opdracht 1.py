# #opdracht 1
# Print onder elkaar de getallen 1 t.m. 25.
# (Let op: je mag maar 4 regels code gebruiken)


for num in range (1,26):
    print(num)

