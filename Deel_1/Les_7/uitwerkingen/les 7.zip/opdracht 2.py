# opdracht 2

# Print 20 keer:
# "Ik ben hard op weg developer te worden!"
# (Let op: je mag maar 4 regels code gebruiken)

zin = "ik ben hard op weg developer te worden"

print(zin*20)



