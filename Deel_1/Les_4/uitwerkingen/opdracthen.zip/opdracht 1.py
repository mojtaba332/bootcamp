#Opdracht 1: 
#Operators, wat zijn dat?
#Maak een programma wat de volgende sommetjes uitrekent.
#Kun je de uitkomst verklaren? 
#print( 15+4 )
#print( 15-4 )
#print( 15*4 )
#print( 15/4 )
#print( 15//4 )
#print( 15**4 )
#print( 15%4 )

print( 15+4 )
print( 15-4 )
print( 15*4 )
print( 15/4 )
print( 15//4 )
print( 15**4 )
print( 15%4 )
