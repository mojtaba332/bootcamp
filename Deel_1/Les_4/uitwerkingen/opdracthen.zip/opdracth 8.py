# Opdracht 8:
# Schrijf een programma wat uitrekent hoeveel keer 13 (helemaal) in 625 past!
# Bereken ook wat er overblijft.
# (hint: gebruik de modulo en integer deling (of floor division))


aantal_keer = 625 // 13
over_blijft = 625 % 13



print(f"13 past {aantal_keer} keer in 625.")
print(f"Er blijft {over_blijft} over. ")

