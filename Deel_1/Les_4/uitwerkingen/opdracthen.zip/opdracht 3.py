# Opdracht 3:
# Maak een variabele naam en geef deze variabele je eigen naam als waarde.
# Schrijf vervolgens een statement wat afdrukt:
#  Hallo + eigen naam +, ik leer nu programmeren. 

# Welke operator(s) gebruik je in dit programma?
# Verander de waarde van naam naar de naam van je buurman. 
# Werkt je programma nog steeds goed?


naam = "Ali"
print(f"hallo {naam}, ik leer nu programma ")
