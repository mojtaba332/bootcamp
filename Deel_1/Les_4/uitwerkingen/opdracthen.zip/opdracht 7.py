# Opdracht 7:
# Delen doet soms iets vreemds! Bekijk de volgende code
# print( (431 / 100) * 100 )
# Wat denk je dat eruit komt? En test het daarna eens!
# Wat gebeurt hier? Schrijf dit op als commentaar!

print( (431 / 100) * 100 )  # je kijg meer cijfers na comma.

result = (431 / 100) * 100 
print(int(result))


print  (int((431 / 100) * 100 ))
