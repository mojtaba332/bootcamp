# opdracht 10

second_per_min = 60
dagen_per_jaar = 365
second_per_uur = 60*second_per_min
second_per_dag = 24*second_per_uur
second_per_week = 7*second_per_dag
second_per_maand = 30*second_per_week
second_per_jaar = 365*second_per_maand


print ("seconden in een uur:",second_per_uur)
print ("seconden in een dag:", second_per_dag)
print ("seconden in een week:", second_per_week)
print ("seconden per maand:", second_per_maand)
print ("seconden per jaar:", second_per_jaar)