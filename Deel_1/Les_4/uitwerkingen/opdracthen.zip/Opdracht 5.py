 # Opdracht 5
# Schrijf een programma met twee variabelen.
# Geef de eerste variabele de waarde 25 en de tweede 0.
# Deel variabele een door variabele twee. 
# Wat gebeurt er? 

var_1 = 25
var_2 = 0
print(var_1 / var_2)


