#    Opdracht 2:
 #   Maak een programma wat de volgende sommetjes uitrekent:
 #   print( 5*2 -3+4/2 )
 #   print( 5*2 - 3+4 / 2 )
  #  Krijg je nu dezelfde uitkomst? 

#    Vervolgens de volgende 2: 
 #   print( (5*2) - (3+4) /2 )
  #  print( ((5*2) -(3+4)) / 2 )

#    Vreemd, dezelfde getallen. Kun je de uitkomst verklaren? 
 #   Schrijf wat commentaar in je code waarin je de uitkomst verklaart.


print (5*2-3+4/2)
print (5*2 -3+4 /4)

print( (5*2) - (3+4) /2 )
print ( ((5*2) -(3+4)) / 2 )
print( (431 / 100) * 100 )
print ((2*3 /4) + (5 -6/7) *8 )
print( ((12*13 /14) + (15 -16) /17) *18 )
print( (431 / 100) * 100)
print (625/13)


