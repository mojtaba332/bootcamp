#Opdracht 3:
#    Definieer drie variabelen var1, var2 en var3. Bereken het gemiddelde en 
#    stop het in een variabele gemiddelde. Toon het gemiddelde. Voeg drie commentaren toe.
#    Pas het programma nu zo aan dat de gebruiker getallen kan invoeren.





var1 = float(input("eerst getal: "))
var2 = float(input("tweede getal: "))
var3 = float(input("derde getal: "))

gemiddelde = (var1 + var2 + var3) / 3

print("het gemiddelde is: ", gemiddelde)
