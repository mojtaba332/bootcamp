
#Schrijf code die de oppervlakte van een cirkel berekent, gebruik makend 
#van variabelen straal en pi = 3.14159. Voor het geval je het vergeten bent, de formule is
#straal keer straal keer pi. 
#Toon de uitkomst als volgt: “De oppervlakte van een cirkel met straal ... is ...”





straal = float(25)
pi = 3.14159

oppervlakte = straal * straal * pi


print(f"De oppervlakte van een cirkel met straal {straal} is {oppervlakte:.2f}")
