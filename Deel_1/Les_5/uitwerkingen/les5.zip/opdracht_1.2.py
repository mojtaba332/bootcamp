 #opdarcht 1

# Herstel de fout die je kreeg toen je "Hallo 252, ik leer nu programmeren." probeerde te printen.

print("hallo 252, ik leer nu programmeren")



# opdaracht dree

print(  3* "hallo")
