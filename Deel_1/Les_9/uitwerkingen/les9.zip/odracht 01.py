#Opdracht 1:
#Leg het verschil uit:
#a=5
#b=3
#c=2
#if (a==6 and b==4 or c==2):
#   print("De conditie is waar")
#else: 
#   print("De conditie is niet waar")	
# En: 
# a=5
# b=3
# c=2
# if (a==6 and (b==4 or c==2)):
#    print("De conditie is waar")
# else:
#    print("De conditie is niet waar")

# (geef met commentaar aan in de code wat het verschil is)


a = 5
b = 3
c = 3

if (a==7 and b==2 or c==1):
    print("de conditie is waar. ")
else:
    print("de conditie is niet waar. ")


a=5
b=3
c=2

if (a==5 and (b==6 or c==2)):
    print("De conditie is waar")
else:
    print("De conditie is niet waar")

#Het verschil tussen de twee stukken code is dus de plaatsing van haakjes 