#Opdracht 4: 
#Maak een lijstje van minimaal 6 verschillende vergelijkingen en geef van iedere vergelijking een voorbeeld.
#Bijv.:
#a = 3
#b = 5 
#print(a<b) 
#print(a....
#Schrijf er zo zelf nog eens minimaal 5 en test je code.



a = 2
b = 5
c = 6
d = 4
f = 7
t = 9
print ( a < b)
print ( c < d)
print ( f < t)

