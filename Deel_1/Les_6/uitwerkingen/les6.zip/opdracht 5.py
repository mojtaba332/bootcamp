#opdracht 5


a = 3
b = 7
c = 9

if a > b:
    print(f"variabele a is het grootste want {a} is groter dan {b} ")
elif a < b:
    print(f"varaibele b is het grootste want {b} is groter dan {a}")
else: c > a , b 
print(f"varaiabele c is het grootste want {c} is groter dan {a , b}")


a = float(input("voer de waarde voor a in:"))
b = float(input("voer de waarde voor b in:"))
c = float(input("voer de waarde voor c in:"))
grootste = 
if a > b:
    print (f"varaibele a is het grootste want {a} is groter dan {b}" )
elif a < b:
    print(f"variabele b is het grootste want {b} is groter dan {a}" )
else: c
print(f"varaiabele c is het grootste want {c} is groter dan {a , b}") 
    