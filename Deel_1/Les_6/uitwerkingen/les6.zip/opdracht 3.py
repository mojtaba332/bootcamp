#opdracht 3



#Schrijf een programma met één variabele: leeftijd.
#Als de waarde van de variabele 16 of hoger is print je: 
#"Gefeliciteerd, je mag je brommerrijbewijs halen." 
#Anders print je:
#"Helaas, je zult nog even moeten wachten."

leeftijd = int(input("hoe oud bent U?? "))


if leeftijd >= 16:
    print("Gefeliciteerd, je mag je brommerrijbewijs halen.")
else:
    print("Helaas, je zult nog even moeten wachten.")
