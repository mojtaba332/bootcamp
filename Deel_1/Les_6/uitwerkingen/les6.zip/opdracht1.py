# Opdracht 1:
# Wat klopt er niet in deze code:
# 	"if x = 18:
# 	    print('de waarde van x = 18')"


if x ==  18: 
    print(f"de waarde van {x}. ")
    
          
